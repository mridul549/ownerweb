import React from 'react'

export default function Orders() {
  return (
    <div>
      <h1>orders</h1>
    </div>
  )
}
