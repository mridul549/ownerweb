import React from 'react'

export default function Outlet() {
  return (
    <div>
      <h1>outlet</h1>
    </div>
  )
}
