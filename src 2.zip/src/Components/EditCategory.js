import React from 'react'
import '../css/editcategory.css'

export default function EditCategory() {
  return (
    <div>
        <h4 className='catName'>Category Name</h4>
        
    </div>
  )
}
