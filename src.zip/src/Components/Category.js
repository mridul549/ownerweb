import React from "react";
import "../css/category.css";

export default function Category() {
    return (
        <div className="cat">
            <button className="">
                <img src="https://i.imgur.com/Ru0cbPs.png" alt="img" />
                <p>Fries</p>
            </button>
        </div>
    );
}
